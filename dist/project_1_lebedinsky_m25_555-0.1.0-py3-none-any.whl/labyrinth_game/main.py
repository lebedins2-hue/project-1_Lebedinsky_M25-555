#!/usr/bin/env python
def main():
    return 'Первая попытка запустить проект!'


